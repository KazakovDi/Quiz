export const error = "rgb(250, 82, 82)";
export const calm = "rgb(4, 139, 230)";
export const warning = "rgb(253, 126, 20)";
export const success = "rgb(18, 184, 134)";
export const blocked = "rgb(37, 38, 43)";
export const disabled = "rgb(134, 142, 150)";
export const additional = "rgb(121, 80, 242)";
