export enum responseStatus {
  PENDING = "pending",
  REJECTED = "rejected",
  FULLFILLED = "fullfilled",
  DEFAULT = "undefined",
}
